//
//  main.m
//  AudioLooper
//
//  Created by Bob McCune on 7/7/13.
//  Copyright (c) 2013 TapHarmonic, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "THAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([THAppDelegate class]));
	}
}
